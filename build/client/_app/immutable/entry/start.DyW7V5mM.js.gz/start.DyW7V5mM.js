import{l as o,a as r}from"../chunks/CnJbt4Yb.js";export{o as load_css,r as start};
